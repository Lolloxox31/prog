# prog
Base del sito fotografico!
--------------------------
-Inserita la sezione testimonials con form di invio.<br />
-innserita parte php sia al form di contatto sia al testimonials.<br />
-Testato il funzionamento dell'interazione tra db e php (vedere commenti nell'index.php).<br />
-Aggiunte 3 cards (da personalizzare con testo e foto).<br />
-Aggiunta la parte javascript che si occupa del controllo della form in testimonials.<br />
